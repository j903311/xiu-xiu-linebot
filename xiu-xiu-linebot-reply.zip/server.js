import express from 'express';
import { Client as LineClient } from '@line/bot-sdk';

const app = express();
app.use(express.json());

const lineClient = new LineClient({
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET,
});

app.post('/webhook', async (req, res) => {
  console.log('Webhook received:', JSON.stringify(req.body));

  if (req.body.events && req.body.events.length > 0) {
    for (const ev of req.body.events) {
      if (ev.type === 'message' && ev.message.type === 'text') {
        console.log(`📩 User said: ${ev.message.text}`);

        // 🔹 回覆使用者
        await lineClient.replyMessage(ev.replyToken, [
          { type: 'text', text: `收到：${ev.message.text}` }
        ]);
      }
    }
  }

  res.status(200).send('OK');
});

app.get('/healthz', (req, res) => res.send('ok'));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`🚀 Reply test server running on port ${PORT}`);
});
